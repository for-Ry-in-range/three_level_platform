/**
* Author: Ryan Wong
* Assignment: Rise of the AI
* Date due: 2025-04-05, 11:59pm
* I pledge that I have completed this assignment without
* collaborating with anyone else, in conformance with the
* NYU School of Engineering Policies and Procedures on
* Academic Misconduct.
**/
#include "Lose.h"
#include "Utility.h"

#define LEVEL_WIDTH 14
#define LEVEL_HEIGHT 8

constexpr char CHARACTERS_FILEPATH[] = "assets/characters.png",
ASTRONAUT_FILEPATH[] = "assets/astronaut_16.png",
ENEMY_FILEPATH[]       = "assets/monster.png";

Lose::~Lose()
{
    delete [] m_game_state.enemies;
    delete    m_game_state.player;
    delete    m_game_state.map;
    Mix_FreeChunk(m_game_state.jump_sfx);
    Mix_FreeMusic(m_game_state.bgm);
}

void Lose::initialise()
{
    GLuint player_texture_id = Utility::load_texture(ASTRONAUT_FILEPATH);
    
    int player_walking_animation[4][4] =
        {
            { 1, 5, 9, 13 },
            { 3, 7, 11, 15 },
            { 2, 6, 10, 14 },
            { 0, 4, 8, 12 }
        };

    glm::vec3 acceleration = glm::vec3(0.0f, -4.81f, 0.0f);

    m_game_state.player = new Entity(
        player_texture_id,         // texture id
        5.0f,                      // speed
        acceleration,              // acceleration
        5.0f,                      // jumping power
        player_walking_animation,  // animation index sets
        0.0f,                      // animation time
        4,                         // animation frame amount
        0,                         // current animation index
        4,                         // animation column amount
        4,                         // animation row amount
        0.6f,                      // width
        0.8f,                       // height
        PLAYER
    );
    
    m_game_state.player->set_position(glm::vec3(1.0f, 0.0f, 0.0f));
    
    /**
     Enemies' stuff */
    GLuint enemy_texture_id = Utility::load_texture(ENEMY_FILEPATH);

    m_game_state.enemies = new Entity[ENEMY_COUNT];

    for (int i = 0; i < ENEMY_COUNT; i++)
    {
    m_game_state.enemies[i] =  Entity(enemy_texture_id, 1.0f, 1.0f, 1.0f, ENEMY, WALKER, IDLE);
    }


    m_game_state.enemies[0].set_position(glm::vec3(9.0f, 15.0f, 0.0f));
    m_game_state.enemies[0].set_movement(glm::vec3(0.0f));
    m_game_state.enemies[0].set_acceleration(glm::vec3(0.0f, -9.81f, 0.0f));
    
    m_game_state.enemies[1].set_position(glm::vec3(6.0f, 0.0f, 0.0f));
    m_game_state.enemies[1].set_movement(glm::vec3(0.0f));
    m_game_state.enemies[1].set_acceleration(glm::vec3(0.0f, -9.81f, 0.0f));
    
    m_game_state.enemies[2] =  Entity(enemy_texture_id, 1.0f, 1.0f, 1.0f, ENEMY, TROPHY, IDLE);
    m_game_state.enemies[2].set_position(glm::vec3(12.0f, 2.0f, 0.0f));
    m_game_state.enemies[2].set_movement(glm::vec3(0.0f));
    m_game_state.enemies[2].set_acceleration(glm::vec3(0.0f, -9.81f, 0.0f));
    
    /**
     BGM and SFX
     */
    Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 4096);
    
    m_game_state.bgm = Mix_LoadMUS("assets/space_beat.mp3");
    Mix_PlayMusic(m_game_state.bgm, -1);
    Mix_VolumeMusic(MIX_MAX_VOLUME / 2);
}

void Lose::update(float delta_time)
{
    std::cout<<"losing screen"<<std::endl;
}


void Lose::render(ShaderProgram *g_shader_program)
{
    GLuint chars_texture_id = Utility::load_texture(CHARACTERS_FILEPATH);

    Utility::draw_text(g_shader_program, chars_texture_id, "You lost.", 0.5f, 0.03f,
              glm::vec3(2.9f, -3.5f, 0.0f));
}
